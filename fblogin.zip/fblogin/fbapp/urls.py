from django.conf.urls import url
from .import views
urlpatterns=[
     
      url('detail',views.detail,name='detail'),
      url('edit',views.update, name='edit'),
      url('sign', views.sign, name='sign')
        ]