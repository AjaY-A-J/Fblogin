# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import auth
from django.contrib.auth.models import User
from django.shortcuts import render,redirect
from django.http import HttpResponse
# Create your views here.

def sign(request):
    username = 'username'
    password = 'password'
    # user=User.objects.create_user(username=username,password=password)
    # user.save();
    return render(request, "sign.html")

def login(request):
    username = ['username']
    password = ['password']
    user=auth.authenticate(username=username,password=password)
    return render(request, "login.html")

def detail(request):
    return render(request, "details.html")

def update(request):
    return render(request, "edit.html")

