# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models

# Create your models here.
class sign(models.Model):
    Username = models.CharField(max_length=50)
    Password = models.IntegerField()
class log(models.Model):
    Username=models.CharField(max_length=50)
    Password=models.IntegerField()

class detail(models.Model):
    Username = models.CharField(max_length=50)
    Password = models.IntegerField()
    about=models.CharField(max_length=100)
    image = models.ImageField(upload_to='image')